package com.example.schooltracker.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.schooltracker.R;

public class AddClass extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_class);
    }
}