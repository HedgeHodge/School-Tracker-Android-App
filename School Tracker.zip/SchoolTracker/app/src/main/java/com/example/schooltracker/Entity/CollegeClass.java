package com.example.schooltracker.Entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "classes")
public class CollegeClass {

    @PrimaryKey(autoGenerate = true)
    private int classID;
    private String className;
    private String classStart;
    private String classEnd;
    private String instructorName;
    private int instructorPhone;
    private String classDescription;
    // TODO: Add related assessments
    private boolean notifyEnabled;
    private String classNotes;

    public CollegeClass(String className, String classStart, String classEnd, String instructorName, int instructorPhone, String classDescription, boolean notifyEnabled, String classNotes) {
        this.className = className;
        this.classStart = classStart;
        this.classEnd = classEnd;
        this.instructorName = instructorName;
        this.instructorPhone = instructorPhone;
        this.classDescription = classDescription;
        this.notifyEnabled = notifyEnabled;
        this.classNotes = classNotes;
    }

    public int getClassID() {
        return classID;
    }

    public void setClassID(int classID) {
        this.classID = classID;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getClassStart() {
        return classStart;
    }

    public void setClassStart(String classStart) {
        this.classStart = classStart;
    }

    public String getClassEnd() {
        return classEnd;
    }

    public void setClassEnd(String classEnd) {
        this.classEnd = classEnd;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    public int getInstructorPhone() {
        return instructorPhone;
    }

    public void setInstructorPhone(int instructorPhone) {
        this.instructorPhone = instructorPhone;
    }

    public String getClassDescription() {
        return classDescription;
    }

    public void setClassDescription(String classDescription) {
        this.classDescription = classDescription;
    }

    public boolean isNotifyEnabled() {
        return notifyEnabled;
    }

    public void setNotifyEnabled(boolean notifyEnabled) {
        this.notifyEnabled = notifyEnabled;
    }

    public String getClassNotes() {
        return classNotes;
    }

    public void setClassNotes(String classNotes) {
        this.classNotes = classNotes;
    }

    @Override
    public String toString() {
        return "CollegeClass{" +
                "className='" + className + '\'' +
                ", classStart='" + classStart + '\'' +
                ", classEnd='" + classEnd + '\'' +
                ", instructorName='" + instructorName + '\'' +
                ", instructorPhone=" + instructorPhone +
                ", classDescription='" + classDescription + '\'' +
                ", notifyEnabled=" + notifyEnabled +
                ", classNotes='" + classNotes + '\'' +
                '}';
    }
}
