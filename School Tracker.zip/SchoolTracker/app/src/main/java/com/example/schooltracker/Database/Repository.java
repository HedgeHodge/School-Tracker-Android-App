package com.example.schooltracker.Database;

import android.app.Application;

import com.example.schooltracker.DAO.AssessmentDAO;
import com.example.schooltracker.DAO.CollegeClassDAO;
import com.example.schooltracker.DAO.TermDAO;
import com.example.schooltracker.Entity.Assessment;
import com.example.schooltracker.Entity.CollegeClass;
import com.example.schooltracker.Entity.Term;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {
    private TermDAO mTermDAO;
    private CollegeClassDAO mCollegeClassDAO;
    private AssessmentDAO mAssessmentDAO;
    private List<Term>  mAllTerms;
    private List<CollegeClass> mAllCollegeClasses;
    private List<Assessment> mAllAssessments;

    private static int NUMBER_OF_THREADS=4;
    static final ExecutorService databaseExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public Repository(Application application) {
        SchoolDatabaseBuilder db=SchoolDatabaseBuilder.getDatabase(application);
        mTermDAO = db.termDAO();
        mCollegeClassDAO = db.collegeClassDAO();
        mAssessmentDAO = db.assessmentDAO();
    }
    public void insert(Term term) {
        databaseExecutor.execute(()->{
            mTermDAO.insert(term);
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void insert(CollegeClass collegeClass) {
        databaseExecutor.execute(()->{
            mCollegeClassDAO.insert(collegeClass);
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void insert(Assessment assessment) {
        databaseExecutor.execute(()->{
            mAssessmentDAO.insert(assessment);
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void update(Term term) {
        databaseExecutor.execute(()->{
            mTermDAO.update(term);
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void update(CollegeClass collegeClass) {
        databaseExecutor.execute(()->{
            mCollegeClassDAO.insert(collegeClass);
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void update(Assessment assessment) {
        databaseExecutor.execute(()->{
            mAssessmentDAO.insert(assessment);
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void delete(Term term) {
        databaseExecutor.execute(()->{
            mTermDAO.delete(term);
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void delete(CollegeClass collegeClass) {
        databaseExecutor.execute(()->{
            mCollegeClassDAO.delete(collegeClass);
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void delete(Assessment assessment) {
        databaseExecutor.execute(()->{
            mAssessmentDAO.delete(assessment);
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public List<Term> getAllTerms() {
        databaseExecutor.execute(()->{
            mAllTerms = mTermDAO.getAllTerms();
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
        return mAllTerms;
    }

    public List<CollegeClass> getAllClasses() {
        databaseExecutor.execute(()->{
            mAllCollegeClasses = mCollegeClassDAO.getAllClasses();
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
        return mAllCollegeClasses;
    }

    public List<Assessment> getAllAssessments() {
        databaseExecutor.execute(()->{
            mAllAssessments = mAssessmentDAO.getAllAssessments();
        });
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
        return mAllAssessments;
    }
}
