package com.example.schooltracker.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.schooltracker.Entity.CollegeClass;
import com.example.schooltracker.Entity.Term;

import java.util.List;

@Dao
public interface CollegeClassDAO {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(CollegeClass collegeClass);

    @Update
    void update(CollegeClass collegeClass);

    @Delete
    void delete(CollegeClass collegeClass);

    @Query("SELECT * FROM classes ORDER BY classID ASC")
    List<CollegeClass> getAllClasses();
}
