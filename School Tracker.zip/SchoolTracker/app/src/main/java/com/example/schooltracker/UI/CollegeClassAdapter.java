package com.example.schooltracker.UI;

public class CollegeClassAdapter {
}
