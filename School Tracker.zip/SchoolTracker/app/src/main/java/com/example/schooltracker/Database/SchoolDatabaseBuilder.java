package com.example.schooltracker.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.schooltracker.DAO.AssessmentDAO;
import com.example.schooltracker.DAO.CollegeClassDAO;
import com.example.schooltracker.DAO.TermDAO;
import com.example.schooltracker.Entity.Assessment;
import com.example.schooltracker.Entity.CollegeClass;
import com.example.schooltracker.Entity.Term;

@Database(entities = {Term.class, CollegeClass.class, Assessment.class}, version = 2, exportSchema = false)
public abstract class SchoolDatabaseBuilder extends RoomDatabase {
    public abstract TermDAO termDAO();
    public abstract CollegeClassDAO collegeClassDAO();
    public abstract AssessmentDAO assessmentDAO();

    private static volatile SchoolDatabaseBuilder INSTANCE;

    static SchoolDatabaseBuilder getDatabase(final Context context) {
        if(INSTANCE == null) {
            synchronized (SchoolDatabaseBuilder.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), SchoolDatabaseBuilder.class, "mySchoolDatabase.db")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
