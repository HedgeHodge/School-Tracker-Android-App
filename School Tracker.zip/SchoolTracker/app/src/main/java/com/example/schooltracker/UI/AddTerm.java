package com.example.schooltracker.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.schooltracker.Database.Repository;
import com.example.schooltracker.Entity.Term;
import com.example.schooltracker.R;

public class AddTerm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_term);
    }

    public void btnSaveTerm(View view) {
        Repository repo = new Repository(getApplication());
        EditText termName = (EditText)findViewById(R.id.termName);
        EditText startDate = (EditText)findViewById(R.id.startDate);
        EditText endDate = (EditText)findViewById(R.id.endDate);
        Term newTerm = new Term(termName.getText().toString(), startDate.getText().toString(), endDate.getText().toString());
        repo.insert(newTerm);
        this.finish();
    }
}